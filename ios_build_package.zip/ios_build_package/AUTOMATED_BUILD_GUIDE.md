# 🚀 SISPEG iOS Automated Build Guide

## 📋 Overview
iOS builds require macOS with Xcode, but you can automate the process using CI/CD services instead of doing it manually on a Mac computer.

## 🎯 Available Options

### 1. **Codemagic (Recommended)**
Cloud-based CI/CD with macOS builders.

#### Setup Steps:
1. **Create Codemagic Account**: https://codemagic.io/
2. **Connect Repository**: Link your GitHub/GitLab repo
3. **Use Configuration**: The `codemagic.yaml` file is already configured
4. **Configure App Store Connect**:
   - Generate API Key in App Store Connect
   - Add to Codemagic environment variables:
     - `APP_STORE_CONNECT_PRIVATE_KEY`
     - `APP_STORE_CONNECT_KEY_IDENTIFIER`
     - `APP_STORE_CONNECT_ISSUER_ID`

#### Benefits:
- ✅ Free tier available
- ✅ Automatic builds on code changes
- ✅ Direct TestFlight/App Store deployment
- ✅ No need for local Mac

### 2. **GitHub Actions**
Free automated builds using GitHub's macOS runners.

#### Setup Steps:
1. **Enable GitHub Actions** in your repository
2. **Add Workflow File**: The `.github/workflows/ios-build.yml` is ready
3. **Configure Secrets**:
   - Go to repository Settings > Secrets and variables > Actions
   - Add App Store Connect credentials as secrets

#### Benefits:
- ✅ Completely free for public repos
- ✅ Integrated with GitHub
- ✅ Automatic builds on push/PR

### 3. **App Center (Microsoft)**
Free for basic builds with deployment to TestFlight.

#### Setup Steps:
1. **Create App Center Account**: https://appcenter.ms/
2. **Connect Repository**: Link GitHub/GitLab
3. **Configure Build**:
   - Select iOS platform
   - Use Cordova build commands
   - Enable TestFlight distribution

#### Benefits:
- ✅ Free unlimited builds
- ✅ Easy TestFlight distribution
- ✅ Build status notifications

### 4. **Bitrise**
Professional CI/CD with excellent iOS support.

#### Setup Steps:
1. **Create Bitrise Account**: https://bitrise.io/
2. **Add App**: Connect repository
3. **Use Cordova Workflow**: Pre-configured iOS Cordova workflow
4. **Configure Deployment**: TestFlight/App Store steps

#### Benefits:
- ✅ Powerful iOS-specific features
- ✅ Extensive integrations
- ✅ Professional support

## 🛠️ Manual Build (If No CI/CD)

If you prefer manual builds, you need a Mac with:

### Requirements:
- ✅ macOS 12.0 or later
- ✅ Xcode 14.0 or later
- ✅ Command Line Tools: `xcode-select --install`
- ✅ Node.js and Cordova: `npm install -g cordova`
- ✅ CocoaPods (optional): `sudo gem install cocoapods`

### Build Steps:
```bash
# 1. Extract ios_build_package.zip on Mac
# 2. Open Terminal in the package folder
chmod +x build_ios.sh
./build_ios.sh

# 3. Open the generated Xcode project
open mobile/ios_build_YYYYMMDD_HHMMSS/SISPEG.xcodeproj

# 4. In Xcode:
# - Select your development team
# - Configure signing certificates
# - Product > Archive
# - Distribute to TestFlight/App Store
```

## 📊 Comparison Table

| Service | Cost | Ease of Setup | Automation | TestFlight Deploy |
|---------|------|---------------|------------|-------------------|
| Codemagic | Free tier | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ✅ |
| GitHub Actions | Free | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ✅ |
| App Center | Free | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ✅ |
| Bitrise | Paid | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ✅ |
| Manual | Free (Mac needed) | ⭐⭐ | ❌ | ✅ |

## 🎯 Recommended Approach

### For Beginners:
1. **Use App Center** - Easiest setup, free, good TestFlight integration
2. **Alternative: Codemagic** - More powerful, still easy

### For Advanced Users:
1. **GitHub Actions** - Free, full control, integrated with GitHub
2. **Bitrise** - Professional features, extensive iOS support

## 📞 Support

If you need help setting up automated builds:
- Check the service's documentation
- Join their community forums
- Contact the SISPEG developer for assistance

## ✅ Checklist

- [ ] Choose CI/CD service
- [ ] Create account and connect repository
- [ ] Configure App Store Connect API keys
- [ ] Test build pipeline
- [ ] Enable automatic builds on push
- [ ] Configure TestFlight distribution
- [ ] Test end-to-end deployment

---

**🎉 With automated builds, you can deploy iOS updates without needing a Mac computer!**