# 📱 SISPEG iOS Production Deployment Guide

## Prerequisites

### Apple Developer Account
- **Apple Developer Program** ($99/year)
- **App Store Connect** access
- **Xcode** installed on macOS

### App Store Setup
1. **Create App ID** di Apple Developer Console
2. **Create App** di App Store Connect
3. **Configure App Information**
   - Name: SISPEG Mobile
   - Bundle ID: `com.sistemkeuangan.sispeg`
   - SKU: `SISPEG-2.1.0`

## 🔧 Configuration Setup

### 1. Update App Store ID
Edit file `cordova_project/www/index.html`:
```javascript
const appStoreId = '123456789'; // Replace with actual App Store ID
```

### 2. Update Config.xml
```xml
<widget id="com.sistemkeuangan.sispeg" version="2.1.0">
    <name>SISPEG Mobile</name>
    <description>Sistem Penggajian Modern</description>
```

## 🏗️ Build Process

### Step 1: Build iOS App
```bash
cd mobile
chmod +x build_ios.sh
./build_ios.sh
```

### Step 2: Open in Xcode
```
open mobile/ios_build_[DATE]/SISPEG.xcodeproj
```

### Step 3: Configure Signing
1. **Select Team** di Xcode
2. **Enable Automatic Signing**
3. **Configure Provisioning Profile**

### Step 4: Archive App
1. **Product → Archive** di Xcode
2. **Wait for archiving** to complete
3. **Click Distribute App**

### Step 5: Upload to App Store
1. **Select "App Store Connect"**
2. **Choose distribution method**
3. **Upload build**

## 📋 App Store Connect Setup

### App Information
- **Primary Language**: Indonesian
- **Category**: Business/Productivity
- **Content Rights**: Full rights

### Version Information
- **Version**: 2.1.0
- **Copyright**: © 2025 Sistem Keuangan Sekolah
- **What's New**:
  ```
  ✨ UI/UX Modern dengan Material Design
  🔄 Auto-update melalui App Store
  📱 Offline capabilities
  🚀 Performance improvements
  ```

### Screenshots (Required)
Upload screenshots untuk:
- iPhone 6.5" (iPhone 13 Pro Max, iPhone 12 Pro Max)
- iPhone 5.5" (iPhone 8 Plus, iPhone 7 Plus)
- iPad Pro (12.9-inch) (3rd generation)
- iPad Pro (12.9-inch) (2nd generation)

### App Review Information
- **Demo Account**: Provide test credentials
- **Notes**: "App requires internet for initial setup"

## 🔄 Update Process

### For Future Updates:
1. **Increment version** in `config.xml`
2. **Build new iOS app**
3. **Upload to App Store Connect**
4. **Submit for review**
5. **Auto-update** handled by iOS

### Update Notification:
- iOS automatically notifies users
- Users can update through App Store
- No manual APK installation needed

## 🧪 Testing

### TestFlight Beta Testing
1. **Upload build** to TestFlight
2. **Invite testers** via email
3. **Collect feedback**
4. **Fix issues** before production

### Production Testing
- **Internal testing** before App Store submission
- **Device compatibility** testing
- **Network condition** testing

## 📊 App Store Optimization (ASO)

### Keywords
- sistem penggajian, absensi karyawan, fingerprint attendance, payroll system

### Description
Sistem Penggajian Modern dengan fitur absensi fingerprint, auto-update, dan UI modern untuk kemudahan pengelolaan data karyawan.

## 🚨 Important Notes

### App Store Review
- **Review time**: 1-3 days typically
- **Rejection reasons**: Usually metadata or functionality issues
- **Appeal process**: Available if rejected

### Bundle ID
- Must match exactly: `com.sistemkeuangan.sispeg`
- Cannot be changed after App Store submission

### Version Numbering
- Use semantic versioning: Major.Minor.Patch
- Must be unique for each submission

## 📞 Support

For issues with iOS deployment:
1. Check Xcode build logs
2. Verify provisioning profiles
3. Ensure bundle ID matches
4. Test on physical devices

## ✅ Checklist Before Submission

- [ ] App Store Connect app created
- [ ] Bundle ID configured correctly
- [ ] Screenshots uploaded (all sizes)
- [ ] App description and keywords set
- [ ] Demo account credentials provided
- [ ] Build archived successfully
- [ ] TestFlight testing completed
- [ ] Version number incremented
- [ ] Privacy policy URL set (if required)